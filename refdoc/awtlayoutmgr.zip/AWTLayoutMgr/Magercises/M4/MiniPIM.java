// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/AWT11/magercises/LayoutPim/MiniPIM.java#2 $
/* Skeleton code for Mini Personal Information Manager
 * In this skeleton code, comments marked with 
 *   //--> 
 * are instructions for what you need to add
 */



//--> Add necessary import statements
import java.awt.Frame;
import java.awt.Button;
import java.awt.MenuBar;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.Dialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;


/** Mini Personal Information Manager GUI 
 *  Note that the only functionality provided is movement between
 *    cards in the CardLayout
 */
public class MiniPIM extends Frame {
  //--> the variables that are already defined here are here so the
  //    skeleton can provide event handling code.
  //--> you will need to add other variables as you see fit

  // selection buttons
  private Button calcButton     = new Button("Calculator");
  private Button toDoButton     = new Button("To-Do List");
  private Button noteButton     = new Button("Note Pad");
  private Button aboutOkButton  = new Button("Ok");

  // menu items
  private MenuItem exitOption   = new MenuItem("Exit");
  private MenuItem aboutOption  = new MenuItem("About");

  // A simple "about" dialog
  private Dialog aboutDialog    = new Dialog(this, "About...");


  /** A main method to start the GUI */
  public static void main(String[] args) {
    //--> create a new MiniPIM instance and display it
  }


  /** Constructor to build the MiniPIM */
  public MiniPIM() {
    //--> create the GUI

    //--> make sure the open, save and save-as menu options
    //    are disabled to start, as the calculator will be the initial
    //    component
    setupEventHandlers();
  }


  /** Add event handlers to move between cards */
  protected void setupEventHandlers() {
    calcButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        //--> make the calculator in the CardLayout visible
        //--> disable the open, save and save-as menu options
      }});

    toDoButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        //--> make the calculator in the CardLayout visible
        //--> enable the open, save and save-as menu options
      }});

    noteButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        //--> make the notepad in the CardLayout visible
        //--> enable the open, save and save-as menu options
      }});

    aboutOkButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        //--> stop displaying the about dialog
      }});

    exitOption.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.exit(0);
      }});

    aboutOption.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        //--> display the about dialog
      }});

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }});
  }
}
