h41484
s 00000/00000/00000
d R 1.2 99/05/21 13:59:54 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/GUI/AWTLayoutMgr/Magercises/M4/solution/minipim/MiniPIM.java
e
s 00255/00000/00000
d D 1.1 99/05/21 13:59:53 czehner 1 0
c date and time created 99/05/21 13:59:53 by czehner
e
u
U
f e 0
t
T
I 1
package minipim;

import java.awt.Button;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.Label;
import java.awt.List;
import java.awt.Font;
import java.awt.Color;
import java.awt.TextField;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Menu;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/** Mini Personal Information Manager GUI 
 *  Note that the only functionality provided is movement between
 *    cards in the CardLayout
 */
public class MiniPIM extends Frame {
  // selection buttons
  private Button calcButton     = new Button("Calculator");
  private Button toDoButton     = new Button("To-Do List");
  private Button noteButton     = new Button("Note Pad");
  private Panel  mainChunk      = new Panel();

  // the main CardLayout (for ease of switching
  private CardLayout cardLayout = new CardLayout();

  // the sub-GUI main panels
  private Panel calcPanel       = new Panel();
  private Panel toDoPanel       = new Panel();
  private Panel notePanel       = new Panel();

  // Menus and Menu Items
  private Menu     fileMenu     = new Menu("File");
  private MenuItem openOption   = new MenuItem("Open");
  private MenuItem saveOption   = new MenuItem("Save");
  private MenuItem saveAsOption = new MenuItem("Save As");
  private MenuItem exitOption   = new MenuItem("Exit");

  private Menu     helpMenu     = new Menu("Help");
  private MenuItem aboutOption  = new MenuItem("About");

  // A simple "about" dialog
  private Dialog aboutDialog    = new Dialog(this, "About...");
  private Button aboutOkButton  = new Button("Ok");

  // define some constant string key to assist selection in CardLayout
  private static final String CALC_KEY  = "calc";
  private static final String TODO_KEY  = "todo";
  private static final String NOTE_KEY  = "note";


  /** A main method to start the GUI */
  public static void main(String[] args) {
    (new MiniPIM()).setVisible(true);
  }


  /** Constructor to build the MiniPIM */
  public MiniPIM() {
    // start our overall GUI with buttons at the NORTH, CardLayout in CENTER
    setLayout(new BorderLayout());

    // Create a panel for the selection buttons
    Panel selectionButtons = new Panel(new FlowLayout());
    selectionButtons.add(calcButton);
    selectionButtons.add(toDoButton);
    selectionButtons.add(noteButton);


    // Create the main chunk of the GUI    
    mainChunk.setLayout(cardLayout);
    mainChunk.add(CALC_KEY,  getCalculator());
    mainChunk.add(TODO_KEY,  getToDoList());
    mainChunk.add(NOTE_KEY,  getNotePad());
    
    // put it all together
    add(selectionButtons, BorderLayout.NORTH);
    add(mainChunk,        BorderLayout.CENTER);
    pack();

    // define the about dialog
    aboutDialog.setLayout(new BorderLayout());
    Panel aboutBottom = new Panel(new FlowLayout(FlowLayout.RIGHT));
    aboutBottom.add(aboutOkButton);
    aboutDialog.add(new Label("Mini Personal Information Manager"), 
                    BorderLayout.NORTH);
    aboutDialog.add(aboutBottom, BorderLayout.SOUTH);

    setupMenus();
    setupEventHandlers();
  }


  /** Connect the menus */
  protected void setupMenus() {
    MenuBar mb = new MenuBar();
    mb.add(fileMenu);
    mb.add(helpMenu);

    fileMenu.add(openOption);
    fileMenu.add(saveOption);
    fileMenu.add(saveAsOption);
    fileMenu.add(exitOption);

    helpMenu.add(aboutOption);
    setMenuBar(mb);

    // initial display is calculator
    // open, save and save as do not apply
    openOption.setEnabled(false);
    saveOption.setEnabled(false);
    saveAsOption.setEnabled(false);
  }

  
  // Sub-GUI definitions
  // Note that many of the variables defined in these methods would need
  //   to become instance variables of this class when event handling is
  //   added to make this a really functional program.  For purposes of
  //   simplicity, we are making these variables local for now

  /** Create the Calculator sub-GUI */
  protected Panel getCalculator() {
    Panel calcBase = new Panel(new BorderLayout());

    // create the display for the calculator
    // we'll make it a green-on-black label
    Label display = new Label("123.456", Label.RIGHT);
    display.setBackground(Color.black);
    display.setForeground(Color.green);

    // Italicize the display font and make it bigger
    Font displayFont = new Font("monospaced", Font.ITALIC, 24);
    display.setFont(displayFont);

    // create the (overly-simple) keypad
    Panel keyPad = new Panel(new GridLayout(4,0));
    keyPad.add(new Button("7"));
    keyPad.add(new Button("8"));
    keyPad.add(new Button("9"));
    keyPad.add(new Button("/"));
    keyPad.add(new Button("4"));
    keyPad.add(new Button("5"));
    keyPad.add(new Button("6"));
    keyPad.add(new Button("X"));
    keyPad.add(new Button("1"));
    keyPad.add(new Button("2"));
    keyPad.add(new Button("3"));
    keyPad.add(new Button("-"));
    keyPad.add(new Button("0"));
    keyPad.add(new Button("."));
    keyPad.add(new Button("="));
    keyPad.add(new Button("+"));

    // add the display and keypad to the calculator
    calcBase.add(display, BorderLayout.NORTH);
    calcBase.add(keyPad,  BorderLayout.CENTER);

    return calcBase;
  }


  /** Create the To-Do List sub-GUI */
  protected Panel getToDoList() {
    Panel toDoBase = new Panel(new BorderLayout());

    // Set up two control buttons
    Panel toDoControl = new Panel(new FlowLayout());
    toDoControl.add(new Button("Add"));
    toDoControl.add(new Button("Remove"));

    // Put the control panel and the entry field together
    Panel bottomChunk = new Panel(new BorderLayout());
    bottomChunk.add(new TextField("<new entry>"), BorderLayout.NORTH);
    bottomChunk.add(toDoControl, BorderLayout.SOUTH);
    
    // Stick the controls and the List in the main panel
    List items = new List();
    items.addItem("Get up");
    items.addItem("Brush teeth");
    items.addItem("Walk dog");
    items.addItem("Fire agent");
    toDoBase.add(items, BorderLayout.CENTER);
    toDoBase.add(bottomChunk, BorderLayout.SOUTH);

    return toDoBase;
  }


  /** Create the Note Pad sub-GUI */
  protected TextArea getNotePad() {
    return new TextArea();
  }


  /** Add event handlers to move between cards */
  protected void setupEventHandlers() {
    calcButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cardLayout.show(mainChunk, CALC_KEY);
        openOption.setEnabled(false);
        saveOption.setEnabled(false);
        saveAsOption.setEnabled(false);
      }});
    toDoButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cardLayout.show(mainChunk, TODO_KEY);
        openOption.setEnabled(true);
        saveOption.setEnabled(true);
        saveAsOption.setEnabled(true);
      }});
    noteButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cardLayout.show(mainChunk, NOTE_KEY);
        openOption.setEnabled(true);
        saveOption.setEnabled(true);
        saveAsOption.setEnabled(true);
      }});
    aboutOkButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        aboutDialog.setVisible(false);
      }});
    exitOption.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setVisible(false);
        dispose();
        System.exit(0);
      }});
    aboutOption.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        aboutDialog.pack();
        aboutDialog.setVisible(true);
      }});
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        setVisible(false);
        dispose();
        System.exit(0);
      }});
  }
}
E 1
