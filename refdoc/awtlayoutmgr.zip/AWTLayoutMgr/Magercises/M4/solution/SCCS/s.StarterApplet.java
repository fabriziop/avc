h24022
s 00000/00000/00000
d R 1.2 99/05/21 14:00:09 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/GUI/AWTLayoutMgr/Magercises/M4/solution/StarterApplet.java
e
s 00021/00000/00000
d D 1.1 99/05/21 14:00:08 czehner 1 0
c date and time created 99/05/21 14:00:08 by czehner
e
u
U
f e 0
t
T
I 1
// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/AWT11/magercises/LayoutPim/solution/StarterApplet.java#2 $
import java.lang.reflect.*;
import java.applet.*;

/** This is a little utility class that starts an application
 *  from within an applet.  It assumes no command-line parameters.
 *  It uses the reflection API and will not be described in detail...
 */
public class StarterApplet extends Applet {
  public void start() {
    String className = getParameter("className");
    try {
      Class c = Class.forName(className);
      Method m = c.getMethod("main", new Class[] {String[].class});
      m.invoke(null, new Object[] {null});
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}
E 1
