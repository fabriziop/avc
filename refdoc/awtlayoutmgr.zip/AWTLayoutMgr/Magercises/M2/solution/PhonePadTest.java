// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/AWT11/magercises/PhonePad/Solution/PhonePadTest.java#2 $

import java.awt.*;
import java.applet.Applet;

public class PhonePadTest extends Applet {
    public void init() {
        KeyPad k = new KeyPad();
        add(k);
    }
}

class KeyPad extends Panel {
    String[] keys = { "1","2","3",
                      "4","5","6",
                      "7","8","9",
                      "*","0","#" };
    Button[] b = new Button[keys.length];
    public KeyPad() {
        setLayout(new GridLayout(4,3));
        for (int i=0; i<keys.length; i++) {
            b[i] = new Button(keys[i]);
            add(b[i]);
        }
    }
}
