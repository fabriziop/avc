// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/AWT11/magercises/PhonePad/PhonePadTest.java#2 $

import java.awt.*;
import java.applet.Applet;

public class PhonePadTest extends Applet {
    public void init() {
        KeyPad k = new KeyPad();
        add(k);
    }
}
