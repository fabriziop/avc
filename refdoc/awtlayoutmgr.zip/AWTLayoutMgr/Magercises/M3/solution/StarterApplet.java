// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/AWT11/magercises/LayoutFtp/solution/StarterApplet.java#2 $
import java.lang.reflect.*;
import java.applet.*;

/** This is a little utility class that starts an application
 *  from within an applet.  It assumes no command-line parameters.
 *  It uses the reflection API and will not be described in detail...
 */
public class StarterApplet extends Applet {
  public void start() {
    String className = getParameter("className");
    try {
      Class c = Class.forName(className);
      Method m = c.getMethod("main", new Class[] {String[].class});
      m.invoke(null, new Object[] {null});
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}
