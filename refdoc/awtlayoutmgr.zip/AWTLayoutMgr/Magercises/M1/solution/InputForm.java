// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/AWT11/magercises/InputForm/Solution/InputForm.java#2 $
import java.awt.*;

public class InputForm extends java.applet.Applet {
  public void init() {
    Panel p = new Panel(new BorderLayout());
    Label nameLabel = new Label("Name:");
    TextField entry = new TextField();
    p.add(nameLabel, BorderLayout.WEST);
    p.add(entry, BorderLayout.CENTER);
    setLayout(new BorderLayout());
    add(p, BorderLayout.NORTH);
  }
}


