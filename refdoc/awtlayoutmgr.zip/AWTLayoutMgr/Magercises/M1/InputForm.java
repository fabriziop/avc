// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/AWT11/magercises/InputForm/InputForm.java#2 $
import java.awt.*;

public class InputForm extends java.applet.Applet {
  public void init() {
  }
}


