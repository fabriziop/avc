// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/FirstAppl/FirstAppl.java#2 $
/*
 * Demonstrates that basic use of Swing components are just like
 * old AWT versions.  Illustrates components, frames, layouts, and
 * 1.1 style events.
 */

import java.awt.*;
import java.awt.event.*;
// import the swing package

public class FirstAppl extends Frame {
  // The initial width and height of the frame
  public static int WIDTH = 250;
  public static int HEIGHT = 130;

  public FirstAppl(String lab) {
    super(lab);
    // Set layout to GridLayout - 3 rows x 1 column
    // create each button and label
    // change button color
    // create/associate action listener
    // add to screen
  }

  public static void main(String s[]) {
    FirstAppl frame = new FirstAppl("First Swing Application");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });

    frame.setSize(WIDTH, HEIGHT);
    frame.show();
  }
}
