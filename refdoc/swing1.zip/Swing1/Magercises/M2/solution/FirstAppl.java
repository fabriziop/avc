// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/FirstAppl/Solution/FirstAppl.java#2 $
/*
 * Demonstrates that basic use of Swing components are just like
 * old AWT versions.  Illustrates components, frames, layouts, and
 * 1.1 style events.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FirstAppl extends Frame {
  // The initial width and height of the frame
  public static int WIDTH = 250;
  public static int HEIGHT = 130;

  public FirstAppl(String lab) {
    super(lab);
    setLayout(new GridLayout(3,1));
    JButton top = new JButton("Top");
    top.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.out.println("top");
      }
    });
    JButton bottom = new JButton("Bottom");
    bottom.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.out.println("bottom");
      }
    });
    add(new JLabel("Swing Components are like AWT 1.1"));
    add(top);
    add(bottom);
  }

  public static void main(String s[]) {
    FirstAppl frame = new FirstAppl("First Swing Application");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });

    frame.setSize(WIDTH, HEIGHT);
    frame.show();
  }
}
