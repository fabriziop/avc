// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/Pizza/Solution/Order.java#2 $
/*
 * Demonstrates Toggles.  Create a Pizza order system which has
 * three sizes (Small/Medium/Large) and three possible toppings
 * (Pepperoni, Pineapple, and Green Peppers). After an order,
 * show the pizza picutre.
 */

import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;
import java.util.zip.*;
import java.io.*;
import javax.swing.*;

public class Order extends JFrame {
  // The initial width and height of the frame
  private static int WIDTH = 400;
  private static int HEIGHT = 300;

// brown4
  Color pepperoniColor = new Color (139, 35, 35);
// gold
  Color pineappleColor = new Color (255, 215, 0);
// dark green
  Color pepperColor    = new Color (0, 100, 0);

  public Order (String title) {
    super(title);
    Container content = getContentPane();
    content.setLayout (new BorderLayout(5, 5));
    // Create Sizes
    final ButtonGroup sizeGroup = new ButtonGroup();
    JRadioButton small = new JRadioButton("Small", false);
    small.setActionCommand("Small");
    sizeGroup.add (small);
    JRadioButton medium = new JRadioButton("Medium", false);
    medium.setActionCommand("Medium");
    sizeGroup.add (medium);
    JRadioButton large = new JRadioButton("Large", true);
    large.setActionCommand("Large");
    sizeGroup.add (large);

    // Group Sizes for screen
    Box sizes = Box.createVerticalBox();
    sizes.add(Box.createGlue());
    sizes.add (new JLabel ("Size:"));
    sizes.add (Box.createVerticalStrut (5));
    sizes.add (small);
    sizes.add (Box.createVerticalStrut (5));
    sizes.add (medium);
    sizes.add (Box.createVerticalStrut (5));
    sizes.add (large);
    sizes.add(Box.createGlue());
    content.add (sizes, BorderLayout.WEST);

    // Create Toppings
    final JCheckBox peppers = new JCheckBox("Green Peppers", false);
    final JCheckBox pepperoni = new JCheckBox("Pepperoni", false);
    final JCheckBox pineapple = new JCheckBox("Pineapple", false);

    // Create Icons
    Icon peppersUnselected = new ColoredToggle (pepperColor, false);
    Icon peppersSelected   = new ColoredToggle (pepperColor, true);
    Icon pepperoniUnselected = new ColoredToggle (pepperoniColor, false);
    Icon pepperoniSelected   = new ColoredToggle (pepperoniColor, true);
    Icon pineappleUnselected = new ColoredToggle (pineappleColor, false);
    Icon pineappleSelected   = new ColoredToggle (pineappleColor, true);

    // Setup Toppings
    peppers.setIcon(peppersUnselected);
    peppers.setSelectedIcon(peppersSelected);
    pepperoni.setIcon(pepperoniUnselected);
    pepperoni.setSelectedIcon(pepperoniSelected);
    pineapple.setIcon(pineappleUnselected);
    pineapple.setSelectedIcon(pineappleSelected);

    // Group Toppings for screen
    Box toppings = Box.createVerticalBox();
    toppings.add(Box.createGlue());
    toppings.add (new JLabel ("Toppings:"));
    toppings.add (Box.createVerticalStrut (5));
    toppings.add (peppers);
    toppings.add (Box.createVerticalStrut (5));
    toppings.add (pepperoni);
    toppings.add (Box.createVerticalStrut (5));
    toppings.add (pineapple);
    toppings.add(Box.createGlue());
    content.add (toppings, BorderLayout.EAST);

    // Create Image Area
    final JLabel imageLabel = new JLabel();
    JScrollPane imagePanel = new JScrollPane(imageLabel);
    content.add (imagePanel, BorderLayout.CENTER);

    // Create Order Button
    JButton order = new JButton ("Order Pizza");
    order.addActionListener (new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        // Get label of selected radio button / size
        String sizeString = 
          sizeGroup.getSelection().getActionCommand();
        boolean pepperState = peppers.isSelected();
        boolean pepperoniState = pepperoni.isSelected();
        boolean pineappleState = pineapple.isSelected();
        StringBuffer imagefile = new StringBuffer();
        if (pepperState)
          imagefile.append ("GREEN-");
        if (pineappleState)
          imagefile.append ("PINE-");
        if (pepperoniState)
          imagefile.append ("PEP-");
        imagefile.append (sizeString.toUpperCase());
        imagefile.append (".GIF");
        String fileString = imagefile.toString();
        Icon icon = getIcon(fileString);
        if (icon != null) {
          imageLabel.setIcon (icon);
        } else {
          System.err.println ("Problem getting image files. Be sure pizza.jar in same directory as program.");
        }
      }
    });
    content.add (order, BorderLayout.SOUTH);
  }
  
  private Icon getIcon (String filename) {
    Icon returnIcon = null;
    try {
      ZipFile zip = new ZipFile ("pizza.jar");
      ZipEntry entry = zip.getEntry(filename);
      InputStream is = zip.getInputStream(entry);
      BufferedInputStream bis = new BufferedInputStream (is);
      DataInputStream dis = new DataInputStream (bis);
      byte data[] = new byte[(int)entry.getSize()];
      dis.readFully(data);
      Image image = getToolkit().createImage(data);
      returnIcon = new ImageIcon (image);
    } catch (ZipException e) {
      System.err.println ("Error reading zip.");
    } catch (IOException e) {
      System.err.println ("IO Error reading zip.");
    }
    return returnIcon;
  }

  public static void main(String s[]) {
    Frame frame = new Order ("Pizza Order");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });

    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }

  class ColoredToggle implements Icon {
    Color color;
    boolean state;
    public ColoredToggle (Color c, boolean s) {
      color = c;
      state = s;
    }
    public void paintIcon (Component c, Graphics g, int x, int y) {
      int width = getIconWidth();
      int height = getIconHeight();
      g.setColor(color);
      g.fillRect (x, y, width, height);
      if (state) {
        g.setColor(Color.white);
        g.drawLine (x, y, x+width-1, y+height-1);
        g.drawLine (x, y+height-1, x+width-1, y);
      }
    }
    public int getIconWidth() {
      return 12;
    }
    public int getIconHeight() { 
      return 12;
    }
  }
}
