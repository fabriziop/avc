// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/Pizza/Order.java#2 $
/*
 * Demonstrates Toggles.  Create a Pizza order system which has
 * three sizes (Small/Medium/Large) and three possible toppings
 * (Pepperoni, Pineapple, and Green Peppers). After an order,
 * show the pizza picutre.
 */

import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;
import java.util.zip.*;
import java.io.*;
import javax.swing.*;

public class Order extends JFrame {
  // The initial width and height of the frame
  private static int WIDTH = 400;
  private static int HEIGHT = 300;

// brown4
  Color pepperoniColor = new Color (139, 35, 35);
// gold
  Color pineappleColor = new Color (255, 215, 0);
// dark green
  Color pepperColor    = new Color (0, 100, 0);

  public Order (String title) {
    super(title);
    Container content = getContentPane();
    content.setLayout (new BorderLayout(5, 5));

    // Create Sizes
    // Create a ButtonGroup named sizeGroup
    // Create three JRadioButtons - Small, Medium, Large
    // add buttons to group
    // make ButtonGroup variable final

    // Group Sizes for screen
    // Create a vertical box
    // Add glue
    // Add a "Size" label, and small, medium, and large radio buttons
    // Each is separated by 5 pixels
    // Add glue
    // Add to west area of screen

    // Create Toppings
    // Create three 'final' unselected checkboxes

    // Create Icons
    // Create six icons, two for each of green peppers, pepperoni, and pineapple

    // Setup Toppings
    // Associate the icons to the appropriate checkbox

    // Group Toppings for screen
    // Create a vertical box
    // Add glue
    // Add a "Toppings" label, and green peppers, pepperoni, and pineapple toggles
    // Each is separated by 5 pixels
    // Add glue
    // Add to east area of screen

    // Create Image Area
    // Create a JLabel named imageLabel
    // Create a JScrollPane
    // Put the label in the scroll pane
    // Add to center area of screen

    // Create Order Button
    JButton order = new JButton ("Order Pizza");
    order.addActionListener (new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        // Get label of selected radio button / size
        String sizeString = 
          sizeGroup.getSelection().getActionCommand();
        boolean pepperState = peppers.isSelected();
        boolean pepperoniState = pepperoni.isSelected();
        boolean pineappleState = pineapple.isSelected();
        StringBuffer imagefile = new StringBuffer();
        if (pepperState)
          imagefile.append ("GREEN-");
        if (pineappleState)
          imagefile.append ("PINE-");
        if (pepperoniState)
          imagefile.append ("PEP-");
        imagefile.append (sizeString.toUpperCase());
        imagefile.append (".GIF");
        String fileString = imagefile.toString();
        Icon icon = getIcon(fileString);
        if (icon != null) {
          imageLabel.setIcon (icon);
        } else {
          System.err.println ("Problem getting image files. Be sure pizza.jar in same directory as program.");
        }
      }
    });
    content.add (order, BorderLayout.SOUTH);
  }

  private Icon getIcon (String filename) {
    Icon returnIcon = null;
    try {
      ZipFile zip = new ZipFile ("pizza.jar");
      ZipEntry entry = zip.getEntry(filename);
      InputStream is = zip.getInputStream(entry);
      BufferedInputStream bis = new BufferedInputStream (is);
      DataInputStream dis = new DataInputStream (bis);
      byte data[] = new byte[(int)entry.getSize()];
      dis.readFully(data);
      Image image = getToolkit().createImage(data);
      returnIcon = new ImageIcon (image);
    } catch (ZipException e) {
      System.err.println ("Error reading zip.");
    } catch (IOException e) {
      System.err.println ("IO Error reading zip.");
    }
    return returnIcon;
  }

  public static void main(String s[]) {
    Frame frame = new Order ("Pizza Order");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });

    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }

  class ColoredToggle implements Icon {
    Color color;
    boolean state;
    public ColoredToggle (Color c, boolean s) {
      color = c;
      state = s;
    }
    public void paintIcon (Component c, Graphics g, int x, int y) {
      int width = getIconWidth();
      int height = getIconHeight();
      g.setColor(color);
      g.fillRect (x, y, width, height);
      if (state) {
        g.setColor(Color.white);
        g.drawLine (x, y, x+width-1, y+height-1);
        g.drawLine (x, y+height-1, x+width-1, y);
      }
    }
    public int getIconWidth() {
      return 12;
    }
    public int getIconHeight() { 
      return 12;
    }
  }
}
