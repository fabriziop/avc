// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/Borders/Borders.java#2 $
/*
 * Demonstrates Borders.  Change the default button
 * border and create your own.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// Import the border package

public class Borders extends JFrame {
  // The initial width and height of the frame
  private static int WIDTH = 400;
  private static int HEIGHT = 300;

  public Borders (String title) {
    super(title);

    // Get contents area
    // Change layout to 2x3 grid with 5 pixels all around

    JButton b;

    // Create a JButton labeled One
    // Set its border to a gray LineBorder
    // Add it to the display

    // Create a JButton labeled Two
    // Set its border to an EtchedBorder
    // Add it to the display

    // Create a JButton labeled Three
    // Set its border to an EmptyBorder, with 2 pixel space
    // Add it to the display

    // Create a JButton labeled Four
    // Set its border to a TitledBorder
    // The border should have a sub-border of a black line
    // And display a blue label of "Press Me" in a 10-point,
    // italic Serif font along the top center of the border
    // Add it to the display

    // Create a DoubleBorderedButton
    // Border one is a RAISED BevelBorder
    // top left is blue, bottom right is yellow
    // Border two is a LOWERED BevelBorder
    // top left is yellow, bottom right is blue
    // Set label of button to Five
    // Add it to the display

    // Button six
    b = new DoubleBorderedButton(
      new DashedBorder(Color.blue, 10, 6),
      new DashedBorder (Color.magenta, 3, 3));
    b.setText ("Six");
    content.add (b);
  }

  public static void main (String args[]) {
    Frame frame = new Borders ("Border Buttons");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });

    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }

  // Create a class DoubleBorderedButton
  // The constructor accepts two Border parameters
  // Add a MouseListener that toggles between the two
  // in mousePressed and mouseReleased interface methods

  class DashedBorder implements Border {
    int THICKNESS = 2;
    Color color;
    int dashWidth;
    int dashHeight;
    public DashedBorder () {
      this (Color.black, 2, 2);
    }
    public DashedBorder (Color c, int width, int height) {
      if (width < 1) {
        throw new IllegalArgumentException (
          "Invalid width: " + width);
      }
      if (height < 1) {
        throw new IllegalArgumentException (
          "Invalid height: " + height);
      }
      color = c;
      dashWidth = width;
      dashHeight = height;
    }
    public void paintBorder (Component c, Graphics g, 
                             int x, int y, 
                             int width, int height) {
      Insets insets = getBorderInsets(c);
      g.setColor (color);
      int numWide = (int)Math.round(width / dashWidth);
      int numHigh = (int)Math.round(height / dashHeight);
      int startPoint;
      for (int i=0;i<=numWide;i+=2) {
        startPoint = x + dashWidth * i;
        g.fillRect (startPoint, y, dashWidth, THICKNESS);
        g.fillRect (startPoint, y+height-insets.bottom, 
                    dashWidth, THICKNESS);
      }
      for (int i=0;i<=numHigh;i+=2) {
        startPoint = x + dashHeight * i;
        g.fillRect (x, startPoint, THICKNESS, dashHeight);
        g.fillRect (x+width-insets.right, startPoint, 
                    THICKNESS, dashHeight);
      }
    }

    public boolean isBorderOpaque() {
      return false;
    }

    // Create a getBorderInsets method
    // Have it return an Insets object
    // that is THICKNESS wide/high all around

  }
}
