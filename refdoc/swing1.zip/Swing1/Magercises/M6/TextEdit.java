// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/Editor/TextEdit.java#2 $
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class TextEdit extends JFrame {
  static int WIDTH = 300;
  static int HEIGHT = 400;

  JTextArea pane;
  JLabel statusInfo;

  public TextEdit (String title) {
    super (title);
    setBackground (Color.lightGray);

    // Setup Screen

    // From top to bottom, have a JToolBar
    // JTextArea, and JLabel.

    // Make toolbar not floatable

    // Setup Menus

    // Create toolbar

    // Create a menu labeled File, accelerator F

    // Create a menu item New, accelerator N
    // Have it call doNewCommand when selected

    // Create a menu item Open, accelerator O
    // Have it call doOpenCommand when selected

    // Create a menu item Save, accelerator S
    // Have it call doSaveCommand when selected

    // Create a separator

    // Create a menu item Close, accelerator C
    // Have it call doCloseCommand when selected

    // Add file menu to menu bar

    // Create a menu labeled Help, accelerator H

    // Create a menu item About, accelerator A
    // Have it call doAboutCommand when selected

    // Add help menu to menu bar


    // Setup Toolbar/Tool Tips

    // Create a button New, tool tip "New File"
    // Have it call doNewCommand when selected

    // Create a button Open, tool tip "Open File"
    // Have it call doOpenCommand when selected

    // Create a button Save, tool tip "Save File"
    // Have it call doSaveCommand when selected

    // Create a separator

    // Create a button About, tool tip "Help - About"
    // Have it call doAboutCommand when selected

  }

  public static void main (String args[]) {
    TextEdit frame = new TextEdit("Mini Text Editor");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });
    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }

  void doNewCommand () {
    pane.setText ("");
  }

  void doAboutCommand() {
    // Create JDialog named 'dialog'

    dialog.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {dialog.dispose();}
    });
    JLabel  lab  = new JLabel ("TextEdit Version 1.0", JLabel.CENTER);
    dialog.getContentPane().add (lab, BorderLayout.CENTER);
    JButton butt = new JButton ("Close");
    dialog.getContentPane().add (butt, BorderLayout.SOUTH);
    butt.addActionListener (new ActionListener () {
      public void actionPerformed(ActionEvent e) {
        dialog.setVisible(false);
        dialog.dispose();
      }
    });
    dialog.setSize (200, 200);
    dialog.setVisible(true);
  }

  void doCloseCommand (int status) {
      System.exit (status);
  }

  void doSaveCommand () {
    FileDialog file = new FileDialog (TextEdit.this, "Save File", FileDialog.SAVE);
    file.show(); // Blocks
    String curFile;
    if ((curFile = file.getFile()) != null) {
      String filename = file.getDirectory() + curFile + "1";
      setCursor (Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      File f = new File (filename);
      try {
        FileWriter fw = new FileWriter (f);
        String text = pane.getText();
        int textsize = text.length();
        fw.write (pane.getText(), 0, textsize);
        fw.close ();
        statusInfo.setText ("Saved: " + filename);
      } catch (IOException exc) {
        statusInfo.setText ("IOException: " + filename);
      }
      setCursor (Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }
  }

  void doOpenCommand () {
    FileDialog file = new FileDialog (TextEdit.this, "Open File", FileDialog.LOAD);
    file.setFile ("*.java");  // Set initial filename filter
    file.show(); // Blocks
    String curFile;
    if ((curFile = file.getFile()) != null) {
      String filename = file.getDirectory() + curFile;
      char[] data;
      setCursor (Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      File f = new File (filename);
      try {
        FileReader fin = new FileReader (f);
        int filesize = (int)f.length();
        data = new char[filesize];
        fin.read (data, 0, filesize);
        pane.setText (new String (data));
        statusInfo.setText ("Loaded: " + filename);
      } catch (FileNotFoundException exc) {
        statusInfo.setText ("File Not Found: " + filename);
      } catch (IOException exc) {
        statusInfo.setText ("IOException: " + filename);
      }
      setCursor (Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }
  }
}
