// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/Editor/Solution/TextEdit.java#2 $
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class TextEdit extends JFrame {
  static int WIDTH = 300;
  static int HEIGHT = 400;
  JTextArea pane;
  JLabel statusInfo;

  public TextEdit (String title) {
    super (title);
    setBackground (Color.lightGray);

    // Setup Screen

    // From top to bottom, have a JToolBar
    // JTextArea, and JLabel.

    Container content = getContentPane();
    JToolBar toolbar = new JToolBar();
    content.add (toolbar, BorderLayout.NORTH);
    pane = new JTextArea ();
    JScrollPane sPane = new JScrollPane (pane);
    content.add (sPane, BorderLayout.CENTER);
    statusInfo = new JLabel();
    content.add (statusInfo, BorderLayout.SOUTH);

    // Make toolbar not floatable
    toolbar.setFloatable (false);

    // Setup Menus

    // Create toolbar
    JMenuBar menuBar = new JMenuBar();
    setJMenuBar (menuBar);

    // Create a menu labeled File, accelerator F
    JMenu file = new JMenu ("File");
    file.setMnemonic (KeyEvent.VK_F);

    // Create a menu item New, accelerator N
    // Have it call doNewCommand when selected
    JMenuItem item;
    file.add (item = new JMenuItem ("New"));
    item.setMnemonic (KeyEvent.VK_N);
    item.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doNewCommand();
      }
    });

    // Create a menu item Open, accelerator O
    // Have it call doOpenCommand when selected
    file.add (item = new JMenuItem ("Open"));
    item.setMnemonic (KeyEvent.VK_O);
    item.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doOpenCommand();
      }
    });

    // Create a menu item Save, accelerator S
    // Have it call doSaveCommand when selected
    file.add (item = new JMenuItem ("Save"));
    item.setMnemonic (KeyEvent.VK_S);
    item.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doSaveCommand();
      }
    });

    // Create a separator
    file.addSeparator();

    // Create a menu item Close, accelerator C
    // Have it call doCloseCommand when selected
    file.add (item = new JMenuItem ("Close"));
    item.setMnemonic (KeyEvent.VK_C);
    item.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doCloseCommand (0);
      }
    });

    // Add file menu to menu bar
    menuBar.add (file);

    // Create a menu labeled Help, accelerator H
    JMenu help = new JMenu ("Help");
    help.setMnemonic (KeyEvent.VK_H);

    // Create a menu item About, accelerator A
    // Have it call doAboutCommand when selected
    help.add (item = new JMenuItem ("About"));
    item.setMnemonic (KeyEvent.VK_A);
    item.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doAboutCommand();
      }
    });

    // Add help menu to menu bar
    menuBar.add (help);

    // Setup Toolbar/Tool Tips

    JButton jb;

    // Create a button New, tool tip "New File"
    // Have it call doNewCommand when selected
    toolbar.add (jb = new JButton ("New"));
    jb.setToolTipText ("New File");
    jb.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doNewCommand();
      }
    });

    // Create a button Open, tool tip "Open File"
    // Have it call doOpenCommand when selected
    toolbar.add (jb = new JButton ("Open"));
    jb.setToolTipText ("Open File");
    jb.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doOpenCommand();
      }
    });

    // Create a button Save, tool tip "Save File"
    // Have it call doSaveCommand when selected
    toolbar.add (jb = new JButton ("Save"));
    jb.setToolTipText ("Save File");
    jb.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doSaveCommand();
      }
    });

    // Create a separator
    toolbar.addSeparator();

    // Create a button About, tool tip "Help - About"
    // Have it call doAboutCommand when selected
    toolbar.add (jb = new JButton ("About"));
    jb.setToolTipText ("Help - About");
    jb.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doAboutCommand();
      }
    });
  }

  public static void main (String args[]) {
    TextEdit frame = new TextEdit("Mini Text Editor");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });
    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }

  void doNewCommand () {
    pane.setText ("");
  }

  void doAboutCommand() {
    final JDialog dialog = new JDialog (this, "About...", true);
    dialog.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {dialog.dispose();}
    });
    JLabel  lab  = new JLabel ("TextEdit Version 1.0", JLabel.CENTER);
    dialog.getContentPane().add (lab, BorderLayout.CENTER);
    JButton butt = new JButton ("Close");
    dialog.getContentPane().add (butt, BorderLayout.SOUTH);
    butt.addActionListener (new ActionListener () {
      public void actionPerformed(ActionEvent e) {
        dialog.setVisible(false);
        dialog.dispose();
      }
    });
    dialog.setSize (200, 200);
    dialog.setVisible(true);
  }

  void doCloseCommand (int status) {
      System.exit (status);
  }

  void doSaveCommand () {
    FileDialog file = new FileDialog (TextEdit.this, "Save File", FileDialog.SAVE);
    file.show(); // Blocks
    String curFile;
    if ((curFile = file.getFile()) != null) {
      String filename = file.getDirectory() + curFile + "1";
      setCursor (Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      File f = new File (filename);
      try {
        FileWriter fw = new FileWriter (f);
        String text = pane.getText();
        int textsize = text.length();
        fw.write (pane.getText(), 0, textsize);
        fw.close ();
        statusInfo.setText ("Saved: " + filename);
      } catch (IOException exc) {
        statusInfo.setText ("IOException: " + filename);
      }
      setCursor (Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }
  }

  void doOpenCommand () {
    FileDialog file = new FileDialog (TextEdit.this, "Open File", FileDialog.LOAD);
    file.setFile ("*.java;*.txt");  // Set initial filename filter
    file.show(); // Blocks
    String curFile;
    if ((curFile = file.getFile()) != null) {
      String filename = file.getDirectory() + curFile;
      char[] data;
      setCursor (Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      File f = new File (filename);
      try {
        FileReader fin = new FileReader (f);
        int filesize = (int)f.length();
        data = new char[filesize];
        fin.read (data, 0, filesize);
        pane.setText (new String (data));
        statusInfo.setText ("Loaded: " + filename);
      } catch (FileNotFoundException exc) {
        statusInfo.setText ("File Not Found: " + filename);
      } catch (IOException exc) {
        statusInfo.setText ("IOException: " + filename);
      }
      setCursor (Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }
  }
}
