// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/FirstSwing/FirstSwing.java#2 $
/*
 * Demonstrates ImageIcons with Buttons.  First use of Swing capabilities.
 */

import java.awt.*;
import java.awt.event.*;
// import the swing package

public class FirstSwing extends JFrame {
  // The initial width and height of the frame
  public static int WIDTH = 300;
  public static int HEIGHT = 300;

  // create image icons for buttons

  public FirstSwing(String lab) {
    super(lab);

    // create each button
    // change color
    // create/associate action listener
    // set accelerator

    // Get contents area
    // Set layout to GridLayout - 2 rows x 1 column
    // add to screen

  }

  public static void main (String args[]) {
    FirstSwing frame = new FirstSwing("First Swing Stuff");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });

    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }
}
