// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/FirstSwing/Solution/FirstSwing.java#2 $
/*
 * Demonstrates ImageIcons with Buttons.  First use of Swing capabilities.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FirstSwing extends JFrame {
  // The initial width and height of the frame
  public static int WIDTH = 300;
  public static int HEIGHT = 300;

  // images for buttons
  public Icon bee = new ImageIcon("bee.gif");
  public Icon dog = new ImageIcon("dog.gif");

  public FirstSwing(String lab) {
    super(lab);
    JButton top = new JButton("A bee", bee);
    top.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.out.println("bee");
      }
    });
    JButton bottom = new JButton("and a dog", dog);
    bottom.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        System.out.println("dog");
      }
    });
    top.setMnemonic (KeyEvent.VK_B);
    bottom.setMnemonic (KeyEvent.VK_D);

    Container content = getContentPane();
    content.setLayout(new GridLayout(2,1));
    content.add(top);
    content.add(bottom);
  }

  public static void main(String args[]) {
    FirstSwing frame = new FirstSwing("First Swing Stuff");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });
    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }
}
