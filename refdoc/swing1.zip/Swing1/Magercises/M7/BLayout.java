// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/BLayout/BLayout.java#2 $
/*
 * Demonstrates BoxLayout.  Create vertical box with two buttons at
 * opposite extremes.  Create horizontal box with three buttons
 * evenly spaced across the space except 5 pixels must be left
 * at the right edge of the box.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.plaf.*;

public class BLayout extends JFrame {
  // The initial width and height of the frame
  private static int WIDTH = 500;
  private static int HEIGHT = 300;
  private static int XSPACE = 5;

  // images for buttons
  Icon rightB = new ImageIcon("bee-right.gif");
  Icon leftB = new ImageIcon("bee-left.gif");
  Icon animB  = new ImageIcon("bee-anim.gif");

  public BLayout(String lab) {
    super(lab);
    setBackground (Color.lightGray);
		
    // Change button background to white
    ColorUIResource backgroundColor =
      new ColorUIResource (Color.white);
    UIDefaults defaults = UIManager.getDefaults();
    defaults.put ("Button.background", backgroundColor);

    // Create a vertical panel with two buttons glued together

    // Create a horizontal panel with three buttons
    // glued together, and a right border of five pixels

    // Get content pane
    // Add the vertical panel to the west
    // Add the horizontal panel to the east
  }

  public static void main(String s[]) {
    BLayout frame = new BLayout("First Swing Stuff");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });

    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }
}
