// Copyright MageLang Institute; Version $Id: //depot/main/src/edu/modules/Swing/magercises/BLayout/Solution/BLayout.java#2 $
/*
 * Demonstrates BoxLayout.  Create vertical box with two buttons at
 * opposite extremes.  Create horizontal box with three buttons
 * evenly spaced across the space except 5 pixels must be left
 * at the right edge of the box.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.plaf.*;

public class BLayout extends JFrame {
  // The initial width and height of the frame
  private static int WIDTH = 500;
  private static int HEIGHT = 300;
  private static int XSPACE = 5;

  // images for buttons
  Icon rightB = new ImageIcon("bee-right.gif");
  Icon leftB = new ImageIcon("bee-left.gif");
  Icon animB  = new ImageIcon("bee-anim.gif");

  public BLayout(String lab) {
    super(lab);
    setBackground (Color.lightGray);

    // Change button background to white
    ColorUIResource backgroundColor =
      new ColorUIResource (Color.white);
    UIDefaults defaults = UIManager.getDefaults();
    defaults.put ("Button.background", backgroundColor);

    // Create a vertical panel
    Box vert = Box.createVerticalBox();
    JButton top = new JButton(rightB);
    JButton bottom = new JButton(leftB);
    vert.add(top);
    vert.add(Box.createGlue());
    vert.add(bottom);

    // Create a horizontal panel
    Box horiz = Box.createHorizontalBox();
    JButton left = new JButton(rightB);
    JButton middle = new JButton(leftB);
    JButton right = new JButton(animB);

    horiz.add(left);
    horiz.add(Box.createGlue());
    horiz.add(middle);
    horiz.add(Box.createGlue());
    horiz.add(right);
    horiz.add(Box.createHorizontalStrut(XSPACE));

    Container content = getContentPane();
    content.add (vert, BorderLayout.WEST);
    content.add (horiz, BorderLayout.CENTER);
  }

  public static void main(String s[]) {
    BLayout frame = new BLayout("Boxing");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });

    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }
}
