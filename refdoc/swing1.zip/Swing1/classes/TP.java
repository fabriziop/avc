import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import java.io.*;
import java.util.*;

public class TP extends JFrame {
  static int WIDTH = 400;
  static int HEIGHT = 300;
  static final String NORMAL = "Normal";
  static final String ITALIC = "Italic";
  static final String BIG = "Big";
  JTextPane pane;
  StyledDocument doc;
  Hashtable paraStyles;

  public TP(String lab) {
    super (lab);

    // Setup Text Pane
    doc = new DefaultStyledDocument();
    pane = new JTextPane (doc);
    JScrollPane scrollPane = new JScrollPane(pane);
    getContentPane().add (scrollPane, BorderLayout.CENTER);

    // Setup initial style set
    paraStyles = new Hashtable();
    SimpleAttributeSet attr = new SimpleAttributeSet();
    paraStyles.put(NORMAL, attr);

    attr = new SimpleAttributeSet();
    StyleConstants.setItalic(attr, true);
    paraStyles.put(ITALIC, attr);

    attr = new SimpleAttributeSet();
    StyleConstants.setFontSize(attr, 36);
    paraStyles.put(BIG, attr);

    // Setup actions
    JButton b1 = new JButton ("Load");
    b1.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doLoadCommand();
      }
    });
    JButton b2 = new JButton ("New");
    b2.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doNewCommand();
      }
    });
    JButton b3 = new JButton ("Change");
    b3.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        doChangeCommand();
      }
    });
    JPanel p = new JPanel ();
    p.add (b1);
    p.add (b2);
    p.add (b3);
    getContentPane().add (p, BorderLayout.SOUTH);
  }

  public static void main (String args[]) {
    JFrame frame = new TP("TextPane Demo");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });
    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
    frame.setBackground (Color.lightGray);
  }

  public void doChangeCommand() {
    pane.setCharacterAttributes ((SimpleAttributeSet) paraStyles.get(BIG), true);
    validate();
  }


  public void doNewCommand() {
    pane.setStyledDocument(doc = new DefaultStyledDocument());
    validate();
  }

  public void doLoadCommand() {
    try {
      // Clear out current document
      pane.setStyledDocument(doc = new DefaultStyledDocument());
      // Get the NORMAL Style
      AttributeSet defaultStyle = (AttributeSet) paraStyles.get(NORMAL);
      // Get the ITALIC Style
      AttributeSet italicStyle = (AttributeSet) paraStyles.get(ITALIC);
      // Get the BIG Style
      AttributeSet bigStyle = (AttributeSet) paraStyles.get(BIG);
      // Insert into pane
      doc.insertString(doc.getLength(), "Hello World\n", bigStyle);
      doc.insertString(doc.getLength(), "What's up Doc?\n", italicStyle);
      doc.insertString(doc.getLength(), "Boring...\n", defaultStyle);
      System.out.println ("Loaded");
      pane.validate();
    } catch (BadLocationException exc) {
      System.out.println ("Error loading");
    }
  }
}
