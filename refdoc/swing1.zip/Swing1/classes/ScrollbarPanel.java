import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ScrollbarPanel extends JPanel {

  public ScrollbarPanel() {
    setLayout(new BorderLayout());
    JScrollBar scrollBar1 = 
      new JScrollBar (JScrollBar.VERTICAL, 0, 5, 0, 100);
    add(scrollBar1, BorderLayout.EAST);
    JScrollBar scrollBar2 = 
      new JScrollBar (JScrollBar.HORIZONTAL, 0, 5, 0, 100);
    add(scrollBar2, BorderLayout.SOUTH);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("JScrollBar Example");
    JPanel j = new ScrollbarPanel ();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.show();
  }
}

