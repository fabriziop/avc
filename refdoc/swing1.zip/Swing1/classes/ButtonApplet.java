import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ButtonApplet extends JApplet {
  public void init() {
    synchronized(SetLF.class) {
      SetLF.setLF(getParameter("lf"), this);
      Icon tigerIcon = new ImageIcon("SmallTiger.gif");
      JButton myButton = new JButton("Tiger", tigerIcon);
      getContentPane().add(myButton, BorderLayout.CENTER);
    }
  }
}
