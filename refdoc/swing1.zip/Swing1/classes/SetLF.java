import java.awt.*;
import javax.swing.*;

public class SetLF {
  static String[][] everywhereLFClasses = 
    {{"Metal",   "javax.swing.plaf.metal.MetalLookAndFeel",},
     {"Motif",   "com.sun.java.swing.plaf.motif.MotifLookAndFeel",},
    };

  static String[][] somewhereLFClasses = 
    {{"Mac",     "com.sun.java.swing.plaf.mac.MacLookAndFeel"},
     {"Multi",   "javax.swing.plaf.multi.MultiLookAndFeel"},
     {"Windows", "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"},
    };

  public static void setLF(String name, JApplet applet) {
    // get the right L&F class
    for(int i = 0; i < somewhereLFClasses.length; i++)
      if (name.equals(somewhereLFClasses[i][0])) {
        try {
          UIManager.setLookAndFeel(somewhereLFClasses[i][1]);
          applet.getContentPane().add(new JLabel("L&F = "+name, SwingConstants.CENTER), BorderLayout.SOUTH);
          return;
        }
        catch (Exception e) {
          // just try Motif instead
          name = "Motif";
        }
      }

    for(int i = 0; i < everywhereLFClasses.length; i++)
      if (name.equals(everywhereLFClasses[i][0])) {
        try {
          UIManager.setLookAndFeel(everywhereLFClasses[i][1]);
          applet.getContentPane().add(new JLabel("L&F = "+name, SwingConstants.CENTER), BorderLayout.SOUTH);
        } 
        catch (Exception exc) {
          System.err.println("Could not load LookAndFeel: " + name);
          System.err.println(exc);
          exc.printStackTrace(System.err);
          applet.getContentPane().add(new JLabel("L&F = <bad>", SwingConstants.CENTER), BorderLayout.SOUTH);
        }
        break;
      }
  }
}	
