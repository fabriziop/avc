import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class PasswordPanel extends JPanel {
  PasswordPanel() {
    JPasswordField pass1 = new JPasswordField(20);
    JPasswordField pass2 = new JPasswordField(20);
    pass2.setEchoChar ('?');
    add(pass1);
    add(pass2);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("Password Example");
    JPanel j = new PasswordPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 150);
    f.show();
  }
}


