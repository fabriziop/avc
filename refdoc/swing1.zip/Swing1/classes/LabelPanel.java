import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LabelPanel extends JPanel {
  public LabelPanel() {
    // Create and add a JLabel
    JLabel plainLabel = new JLabel("Plain Small Label");
    add(plainLabel); 
    // Create a 2nd JLabel
    JLabel fancyLabel = new JLabel("Fancy Big Label"); 
    // Instantiate a Font object to use for the label
    Font fancyFont = new Font("Serif", Font.BOLD | Font.ITALIC, 32); 
    // Associate the font with the label
    fancyLabel.setFont(fancyFont);
    // Create an Icon
    Icon tigerIcon = new ImageIcon("SmallTiger.gif"); 
    // Place the Icon in the label
    fancyLabel.setIcon(tigerIcon);
    // Align the text to the right of the Icon
    fancyLabel.setHorizontalAlignment(JLabel.RIGHT); 
    // Add to panel
    add(fancyLabel);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("Label Example");
    JPanel j = new LabelPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 100);
    f.show();
  }
}
