import java.util.*;
import javax.swing.*;

public class ListView extends JTextArea {
  public ListView(int n) {
    super("", n, 10);
    setEditable(false);
  }

  /* This is NOT tied to a particular model's event.
   * An adaptor is used to isolate the model's type
   * from the view.
   *
   * Method called by adapter
   * resets JTextArea and copies the data model
   * Vector back in
   */
  public void changed (Vector v) {
    setText("");
    Enumeration e = v.elements();
    while (e.hasMoreElements()) {
      Integer i = (Integer)e.nextElement();
      append (i.toString() + "\n");
    }
  }
}
