import java.awt.*;
import javax.swing.*;

public class AppTester extends JApplet {
  public void init () {
    Container c = getContentPane();
    JButton jb = new JButton ("Default");
    c.add (jb, BorderLayout.WEST);
    jb = new JButton ("LayoutManager");
    c.add (jb, BorderLayout.CENTER);
    jb = new JButton ("is");
    c.add (jb, BorderLayout.EAST);
    jb = new JButton ("BorderLayout: " + 
      (c.getLayout() instanceof BorderLayout));
    c.add (jb, BorderLayout.SOUTH);
  }
}
