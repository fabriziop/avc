import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class BorderPanel extends JPanel {

  class MyBorder implements Border {
    Color color;
    public MyBorder (Color c) {
      color = c;
    }
    public void paintBorder (Component c, Graphics g, 
        int x, int y, int width, int height) {
      Insets insets = getBorderInsets(c);
      g.setColor (color);
      g.fillRect (x, y, 2, height);
      g.fillRect (x, y, width, 2);
      g.setColor (color.darker());
      g.fillRect (x+width-insets.right, y, 2, height);
      g.fillRect (x, y+height-insets.bottom, width, 2);
    }
    public boolean isBorderOpaque() {
      return false;
    }
    public Insets getBorderInsets(Component c) {
      return new Insets (2, 2, 2, 2);
    }
  }

  public BorderPanel() {
    setLayout (new GridLayout (4, 3, 5, 5));
    JButton b = new JButton("Empty");
    b.setBorder (new EmptyBorder (1,1,1,1));
    add(b);
    b = new JButton ("Etched");
    b.setBorder (new EtchedBorder ());
    add(b);
    b = new JButton ("ColorizedEtched");
    b.setBorder (new EtchedBorder (Color.red, 
                                    Color.green));
    add(b);
    b = new JButton ("Titled/Line");
    b.setBorder(new TitledBorder (
      new TitledBorder(
        LineBorder.createGrayLineBorder(),
        "Hello"),
      "World",
      TitledBorder.RIGHT,
      TitledBorder.BOTTOM));
    add(b);
    b = new JButton ("Bevel Up");
    b.setBorder(new BevelBorder(BevelBorder.RAISED));
    add(b);
    b = new JButton ("Bevel Down");
    b.setBorder(new BevelBorder(BevelBorder.LOWERED));
    add(b);
    b = new JButton ("Soft Bevel Up");
    b.setBorder(new SoftBevelBorder(SoftBevelBorder.RAISED));
    add(b);
    b = new JButton ("Soft Bevel Down");
    b.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
    add(b);
    b = new JButton ("Matte");
    b.setBorder(new MatteBorder(5, 10, 5, 10, Color.red));
    add(b);
    b = new JButton ("Matte Icon");
    Icon icon = new ImageIcon ("SmallTiger.gif");
    b.setBorder(new MatteBorder(10, 10, 10, 10, icon));
    add(b);

    b = new JButton ("ColorizedBezel");
    b.setBorder(new BevelBorder(BevelBorder.RAISED, 
                                Color.red, Color.pink));
    add(b);
    b = new JButton ("My/Compound");
    b.setBorder(new CompoundBorder(
      new MyBorder(Color.red), 
      new CompoundBorder (new MyBorder(Color.green),
                          new MyBorder(Color.blue))));
    add(b);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("Borders Example");
    JPanel j = new BorderPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (430, 250);
    f.show();
  }
}
