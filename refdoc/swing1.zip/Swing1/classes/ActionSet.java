import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import java.util.Hashtable;

public class ActionSet extends JFrame {
  static int WIDTH = 400;
  static int HEIGHT = 300;

  public ActionSet(String lab) {
    super (lab);

    JTextPane tp = new JTextPane ();
    Hashtable commands = new Hashtable();
    Action actions[] = tp.getActions();
    for (int i = 0; i < actions.length; i++) {
      Action a = actions[i];
      commands.put(a.getValue(Action.NAME), a);
    }
    final Action boldAction = 
      (Action)commands.get ("font-bold");

    // Setup MenuBar
    JMenu menu = new JMenu("Edit");
    JMenuItem menuitem = menu.add (boldAction);
    menuitem.setText("Bold");
    JMenuBar menubar = new JMenuBar();
    menubar.add(menu);

    // Setup ToolBar
    JToolBar toolbar = new JToolBar();
    JButton button = toolbar.add(boldAction);
    button.setText("Bold");

    // Setup toggle button
    JButton toggleButton = 
      new JButton("Toggle Bold Action");
    ActionListener toggleListener = 
      new ActionListener() {
        public void actionPerformed (ActionEvent e) {
          boolean enabled = boldAction.isEnabled();
          boldAction.setEnabled(!enabled);
        }
      };
    toggleButton.addActionListener (toggleListener);

    // Setup screen
    Container contentPane = getContentPane();
    JScrollPane scrollPane = new JScrollPane(tp);
    contentPane.add(menubar, BorderLayout.NORTH);
    contentPane.add(scrollPane, BorderLayout.CENTER);
    contentPane.add(toolbar, BorderLayout.EAST);
    contentPane.add(toggleButton, BorderLayout.SOUTH);
  }

  public static void main (String args[]) {
    JFrame frame = new ActionSet("Action Demo");
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {System.exit(0);}
    });
    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }
}
