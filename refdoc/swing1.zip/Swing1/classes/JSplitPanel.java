import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JSplitPanel extends JPanel {

  public JSplitPanel() {
    setLayout(new BorderLayout());
    JTree tree = new JTree();    
    String[] items = {"a", "two", "three", 
      "four", "five", "six", "seven"};
    JList list = new JList(items);
    JScrollPane left = new JScrollPane(tree);
    JScrollPane right = new JScrollPane(list);
    left.setMinimumSize(new Dimension(0,0));
    right.setMinimumSize(new Dimension(0,0));
    JSplitPane pane = new JSplitPane(
      JSplitPane.HORIZONTAL_SPLIT, left, right);
    pane.setDividerLocation(0.5);    
    pane.setOneTouchExpandable(true);
    add(pane, BorderLayout.CENTER);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("JSplitPane Example");
    JPanel j = new JSplitPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 150);
    f.show();
  }
}
