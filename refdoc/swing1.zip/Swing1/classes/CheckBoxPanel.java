import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CheckBoxPanel extends JPanel {

  Icon unchecked = new ToggleIcon (false);
  Icon checked = new ToggleIcon (true);

  public CheckBoxPanel() {

    // Set the layout for the JPanel
    setLayout(new GridLayout(2, 1));
    // Create checkbox with its state initialized to true
    JCheckBox cb1 = new JCheckBox("Choose Me", true);
    cb1.setIcon(unchecked);
    cb1.setSelectedIcon(checked);
    // Create checkbox with its state initialized to false
    JCheckBox cb2 = new JCheckBox("No Choose Me", false);
    cb2.setIcon(unchecked);
    cb2.setSelectedIcon(checked);
    add(cb1); 
    add(cb2); 
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("CheckBox Example");
    JPanel j = new CheckBoxPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 100);
    f.show();
  }
  class ToggleIcon implements Icon {
    boolean state;
    public ToggleIcon (boolean s) {
      state = s;
    }
    public void paintIcon (Component c, Graphics g, 
                           int x, int y) {
      int width = getIconWidth();
      int height = getIconHeight();
      g.setColor (Color.black);
      if (state)
        g.fillRect (x, y, width, height);
      else
        g.drawRect (x, y, width, height);
    }
    public int getIconWidth() {
      return 10;
    }
    public int getIconHeight() { 
      return 10;
    }
  }
}
