import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SliderPanel extends JPanel {

  public SliderPanel() {
    setLayout(new BorderLayout());
    JSlider slider1 = 
      new JSlider (JSlider.VERTICAL, 0, 100, 50);
    slider1.setPaintTicks(true);
    slider1.setMajorTickSpacing(10);
    slider1.setMinorTickSpacing(2);
    add(slider1, BorderLayout.EAST);
    JSlider slider2 = 
      new JSlider (JSlider.VERTICAL, 0, 100, 50);
    slider2.setPaintTicks(true);
    slider2.setMinorTickSpacing(5);
    add(slider2, BorderLayout.WEST);
    JSlider slider3 = 
      new JSlider (JSlider.HORIZONTAL, 0, 100, 50);
    slider3.setPaintTicks(true);
    slider3.setMajorTickSpacing(10);
    add(slider3, BorderLayout.SOUTH);
    JSlider slider4 = 
      new JSlider (JSlider.HORIZONTAL, 0, 100, 50);
    slider4.setBorder(BorderFactory.createLineBorder(Color.blue));
    add(slider4, BorderLayout.NORTH);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("JSlider Example");
    JPanel j = new SliderPanel ();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.show();
  }
}

