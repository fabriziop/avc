import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.reflect.InvocationTargetException;

public class ProgressBarPanel extends JPanel {
  Thread loadThread;
  Object lock = new Object();
  boolean shouldStop=false;
  JTextField progressTextField;
  JProgressBar progressBar;
  public ProgressBarPanel() {
    setLayout(new BorderLayout());

    progressTextField = new JTextField();
    add(progressTextField, BorderLayout.NORTH);

    JPanel bottomPanel = new JPanel();
    progressBar = new JProgressBar();
    progressBar.setStringPainted(true);
    bottomPanel.setLayout(new GridLayout(0,1));
    bottomPanel.add(progressBar);
    bottomPanel.add(new JLabel("Load Status"));
    JPanel buttonPanel = new JPanel();
    JButton startButton = new JButton("Start");
    buttonPanel.add(startButton);
    startButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        startLoading();
      }
    });
    JButton stopButton = new JButton("Stop");
    buttonPanel.add(stopButton);
    stopButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        stopLoading();
      }
    });
    bottomPanel.add(buttonPanel);
    add(bottomPanel, BorderLayout.SOUTH);
  } 
  public void startLoading() {
    if(loadThread == null) {
      loadThread = new LoadThread();
      shouldStop = false;
      loadThread.start();
    }
  }
  public void stopLoading() {
    synchronized(lock) {
      shouldStop = true;
      lock.notify();
    }
  } 
  class LoadThread extends Thread {
    public void run () {
      int min = 0;
      int max = 100;
      progressBar.setValue(min);
      progressBar.setMinimum(min);
      progressBar.setMaximum(max);
      Runnable runner = new Runnable() {
        public void run() {
          int value = progressBar.getValue();
          value++;
          progressBar.setValue(value);
          progressTextField.setText (""+value);
        }
      };
      for (int i=min;i<=max;i++) {
        try {
          SwingUtilities.invokeAndWait(runner);
        } catch (InvocationTargetException e) {
          break;
        } catch (InterruptedException e) {
            // Ignore Exception
        }
        synchronized(lock) {
          if(shouldStop)
            break;
          try {
            lock.wait(100);
          } catch (InterruptedException e) {
            // Ignore Exception
          }
        }
      }
      loadThread = null;
    }
  } 
  public static void main (String args[]) {
    JFrame f = new JFrame ("ProgressBar Example");
    JPanel j = new ProgressBarPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.show();
  }
}
