import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class TextPanel extends JPanel {
  public TextPanel() {
    // Set the layout to a BorderLayout
    setLayout(new BorderLayout());
    // Create the three basic text components
    JTextField textField = new JTextField();
    textField.setText ("Text Field: Single line of plain text");
    JTextArea textArea = new JTextArea(5, 30);
    textArea.setEditable (false);
    textArea.setText ("Text Area:\nMultiple lines of plain text");
    JTextPane textPane = new JTextPane();
    textPane.setEditable (false);
    textPane.setText ("Text Pane:\nMultiple lines of formatted text with word wrap");

    //Set the textpane's font properties

    MutableAttributeSet attr = new SimpleAttributeSet();
    StyleConstants.setFontFamily(attr, "Serif");
    StyleConstants.setFontSize(attr, 18);
    StyleConstants.setBold(attr, true);
    textPane.setCharacterAttributes(attr, false);

    // Separate the three text components by struts
    // for spacing
    add(textField, BorderLayout.NORTH);
    add(new JScrollPane(textArea), BorderLayout.CENTER);
    add(new JScrollPane(textPane), BorderLayout.SOUTH);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("Text Example");
    JPanel j = new TextPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (321, 234);
    f.show();
  }
}

