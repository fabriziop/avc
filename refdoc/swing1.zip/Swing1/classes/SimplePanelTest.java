// import the symbols from awt and swing packages
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// Subclass JPanel to place widgets in a panel
class SimplePanel extends JPanel {

  // Declare the two components
  JTextField textField;
  JButton button;

  // Add a constructor for our JPanel
  // This is where most of the work will be done
  public SimplePanel() {

    // Create a JButton
    button = new JButton("Clear Text");
    
    // Add the JButton to the JPanel
    add(button);
    
    // Create a JTextField with 10 visible columns
    textField = new JTextField(10);
    
    // Add the JTextField to the JPanel
    add(textField);

    // Add a listener to the JButton
    // that clears the JTextField
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        textField.setText("");
      }
    });
  }
}
    
// Next, create a simple framework
// for displaying our panel
// This framework may be used for displaying other
// panels with minor modifications

// Subclass JFrame so you can display a window
public class SimplePanelTest extends JFrame {

  // Set up constants for width and height of frame
  static final int WIDTH = 300;
  static final int HEIGHT = 100;
   
  // Add a constructor for our frame.
  SimplePanelTest(String title) {
    // Set the title of the frame
    super(title);
    
    // Instantiate and add the SimplePanel to the frame
    SimplePanel simplePanel = new SimplePanel();
    Container c = getContentPane();
    c.add(simplePanel, BorderLayout.CENTER);
  }
      
  // Create main method to execute the application
  public static void main(String args[]) {

    // instantiate a SimplePanelTest object 
    // so you can display it
    JFrame frame = 
      new SimplePanelTest("SimplePanel Example");
    
    // Create a WindowAdapter so the application 
    // is exited when the window is closed.
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    
    // Set the size of the frame and show it
    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
  }   
}
