import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ScrollPanel extends JPanel {

  public ScrollPanel() {
    setLayout(new BorderLayout());
    Icon bigTiger = new ImageIcon("BigTiger.gif");
    JLabel tigerLabel = new JLabel(bigTiger);
    JScrollPane scrollPane = new JScrollPane(tigerLabel);
    add(scrollPane, BorderLayout.CENTER);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("JScrollPane Example");
    JPanel j = new ScrollPanel ();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (340, 400);
    f.show();
  }
}

