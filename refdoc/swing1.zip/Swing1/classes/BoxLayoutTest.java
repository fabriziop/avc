import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class BoxLayoutTest extends JPanel {

  BoxLayoutTest() {
    // Set the layout to a y-axis BoxLayout
    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
      
    // Create three components
    TextField textField = new TextField();
    TextArea textArea = new TextArea(4, 20);
    JButton button = new JButton(
      "Tiger", new ImageIcon("SmallTiger.gif"));

    // Add the three components to the BoxLayout
    add(new JLabel("TextField:"));
    add(textField);
    add(new JLabel("TextArea:"));
    add(textArea);
    add(new JLabel("Button:"));
    add(button);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("BoxLayout Example");
    JPanel j = new BoxLayoutTest();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (321, 234);
    f.show();
  }
}

