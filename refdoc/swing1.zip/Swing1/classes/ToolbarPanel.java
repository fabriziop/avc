import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ToolbarPanel extends JPanel {
  ToolbarPanel() {
    setLayout (new BorderLayout());
    JToolBar toolbar = new JToolBar();
    JButton myButton = new JButton("Hello");
    toolbar.add(myButton);
    Icon tigerIcon = new ImageIcon("SmallTiger.gif");
    myButton = new JButton(tigerIcon);
    toolbar.add(myButton);
    toolbar.addSeparator();
    toolbar.add (new Checkbox ("Not"));
    add (toolbar, BorderLayout.NORTH);
    toolbar = new JToolBar();
    Icon icon = new AnOvalIcon(Color.red);
    myButton = new JButton(icon);
    toolbar.add(myButton);
    icon = new AnOvalIcon(Color.blue);
    myButton = new JButton(icon);
    toolbar.add(myButton);
    icon = new AnOvalIcon(Color.green);
    myButton = new JButton(icon);
    toolbar.add(myButton);
    toolbar.addSeparator();
    icon = new AnOvalIcon(Color.magenta);
    myButton = new JButton(icon);
    toolbar.add(myButton);
    add (toolbar, BorderLayout.SOUTH);
  }
  class AnOvalIcon implements Icon {
    Color color;
    public AnOvalIcon (Color c) {
      color = c;
    }
    public void paintIcon (Component c, Graphics g, 
                          int x, int y) {
      g.setColor(color);
      g.fillOval (x, y, getIconWidth(), getIconHeight());
    }
    public int getIconWidth() {
      return 20;
    }
    public int getIconHeight() { 
      return 10;
    }
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("Toolbar Example");
    f.setBackground (Color.lightGray);
    JPanel j = new ToolbarPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.show();
  }
}
