import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class RadioButtonPanel extends JPanel {

  public RadioButtonPanel() {
    // Set the layout to a GridLayout
    setLayout(new GridLayout(4,1));

    // Declare a radio button
    JRadioButton radioButton;

    // Instantiate a ButtonGroup for functional
    // association among radio buttons
    ButtonGroup rbg = new ButtonGroup();

    // Create a label for the group
    JLabel label = new JLabel("Annual Salary: ");
    label.setFont(new Font("SansSerif", Font.BOLD, 14));
    add(label);

    // Add a new radio button to the pane
    radioButton = new JRadioButton("$45,000");
    radioButton.setMnemonic (KeyEvent.VK_4);
    add (radioButton);

    // Add the button to the ButtonGroup
    rbg.add (radioButton);

    // Set this radio button to be the default
    radioButton.setSelected(true);

    // Set up two more radio buttons
    radioButton = new JRadioButton("$60,000");
    radioButton.setMnemonic (KeyEvent.VK_6);
    add (radioButton);
    rbg.add (radioButton);
    radioButton = new JRadioButton("$75,000");
    radioButton.setMnemonic (KeyEvent.VK_7);
    add (radioButton);
    rbg.add (radioButton);
  }

  public static void main (String args[]) {
    JFrame f = new JFrame ("RadioButton Example");
    JPanel j = new RadioButtonPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (200, 200);
    f.show();
  }
}
