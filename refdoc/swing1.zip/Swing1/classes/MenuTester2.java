import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class MenuTester2 extends JFrame {

  public MenuTester2() {
    super ("Menu Example");

    JMenuBar jmb = new JMenuBar();
    JMenu file = new JMenu ("File");
    file.addMenuListener (new MenuListener() {
      public void menuSelected (MenuEvent e) {
        System.out.println ("Selected");
      }
      public void menuDeselected (MenuEvent e) {
        System.out.println ("Deselected");
      }
      public void menuCanceled (MenuEvent e) {
        System.out.println ("Canceled");
      }
    });
    JMenuItem item;
    file.add (item = new JMenuItem ("New"));
    file.add (item = new JMenuItem ("Open"));
    file.addSeparator();
    file.add (item = new JMenuItem ("Close"));
    jmb.add (file);

    JMenu edit = new JMenu ("Edit");
    edit.add (item = new JMenuItem ("Copy"));
    edit.add (item = new JMenuItem ("Cut"));
    edit.add (item = new JMenuItem ("Paste"));
    jmb.add (edit);

    setJMenuBar (jmb);
  }
  public static void main (String args[]) {
    JFrame f = new MenuTester2 ();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.setSize (300, 200);
    f.show();
  }
}

