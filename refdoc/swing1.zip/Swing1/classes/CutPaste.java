import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;

public class CutPaste extends JPanel {
  CutPaste() {
    setLayout (new BorderLayout (5, 5));
    JTextArea jt = new JTextArea();
    JScrollPane pane = new JScrollPane(jt);
    add(pane, BorderLayout.CENTER);

    // get the command table
    Hashtable commands = new Hashtable();
    Action[] actions = jt.getActions();
    for (int i = 0; i < actions.length; i++) {
      Action a = actions[i];
      commands.put(a.getValue(Action.NAME), a);
    }

    JToolBar bar = new JToolBar();
    AbstractAction cutAction = (AbstractAction)
      commands.get (DefaultEditorKit.cutAction);
    JButton button = bar.add(cutAction);
    button.setText("Cut");
    AbstractAction pasteAction = (AbstractAction)
      commands.get (DefaultEditorKit.pasteAction);
    button = bar.add(pasteAction);
    button.setText("Paste");
    add (bar, BorderLayout.SOUTH);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("CutPaste Example");
    JPanel j = new CutPaste();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.show();
  }
}
