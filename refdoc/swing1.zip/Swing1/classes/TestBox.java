import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TestBox extends Box {
  TestBox() {
    super(BoxLayout.Y_AXIS);

    // Create the three basic text components
    TextField textField = new TextField();
    TextArea textArea = new TextArea(4, 20);
    JButton button = new JButton("Tiger", new
      ImageIcon("SmallTiger.gif"));

    // Separate the three components 
    // by struts for spacing
    add(createVerticalStrut(8));
    add(textField);
    add(createVerticalGlue());
    add(textArea);
    add(createVerticalGlue());
    add(button);
    add(createVerticalStrut(8));
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("TestBox Example");
    Box j = new TestBox();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (321, 234);
    f.show();
  }
}

