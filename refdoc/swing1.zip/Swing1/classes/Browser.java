import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;

public class Browser extends JPanel {
  Browser() {
    setLayout (new BorderLayout (5, 5));
    final JEditorPane jt = new JEditorPane();
    final JTextField input = 
      new JTextField("http://java.sun.com");
    // make read-only
    jt.setEditable(false);
    // follow links
    jt.addHyperlinkListener(new HyperlinkListener () {
      public void hyperlinkUpdate(final HyperlinkEvent e) {
        if (e.getEventType() == 
            HyperlinkEvent.EventType.ACTIVATED) {
          SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              // Save original
              Document doc = jt.getDocument();
              try {
                URL url = e.getURL();
                jt.setPage(url);
                input.setText (url.toString());
              } catch (IOException io) {
                JOptionPane.showMessageDialog (
                  Browser.this, "Can't follow link", 
                  "Invalid Input", 
                   JOptionPane.ERROR_MESSAGE);
                jt.setDocument (doc);
              }
            }
          });
        }
      }
    });
    JScrollPane pane = new JScrollPane();
    pane.setBorder (
      BorderFactory.createLoweredBevelBorder());
    pane.getViewport().add(jt);
    add(pane, BorderLayout.CENTER);

    input.addActionListener (new ActionListener() {
      public void actionPerformed (ActionEvent e) {
        try {
          jt.setPage (input.getText());
        } catch (IOException ex) {
          JOptionPane.showMessageDialog (
            Browser.this, "Invalid URL", 
            "Invalid Input", 
            JOptionPane.ERROR_MESSAGE);
        }
      }
    });
    add (input, BorderLayout.SOUTH);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("Browser Example");
    JPanel j = new Browser();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.show();
  }
}
