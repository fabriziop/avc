import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TooltipPanel extends JPanel {
  public TooltipPanel() {
    JButton myButton = new JButton("Hello");
    myButton.setToolTipText ("World");
    add(myButton);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("Tooltip Example");
    JPanel j = new TooltipPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 100);
    f.show();
  }
}
