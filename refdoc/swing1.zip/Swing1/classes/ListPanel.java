import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ListPanel extends JPanel {
  String label [] = {"Cranberry", "Orange", 
    "Banana", "Kiwi", "Blueberry", "Pomegranate",
    "Apple", "Pear", "Watermelon", "Raspberry",
    "Snozberry"
  };
  public ListPanel() {
    setLayout (new BorderLayout());
    JList list = new JList(label);
    JScrollPane pane = new JScrollPane(list);
    add(pane, BorderLayout.CENTER);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("List Example");
    JPanel j = new ListPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 150);
    f.show();
  }
}
