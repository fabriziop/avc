import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Hashtable;

public class SliderPanel2 extends JPanel {
  public SliderPanel2() {
    setLayout(new BorderLayout());
    JSlider right, bottom;
    right = new JSlider(JSlider.VERTICAL, 1, 9, 3);
    Hashtable h = new Hashtable();
    h.put (new Integer (1), new JLabel("Mercury"));
    h.put (new Integer (2), new JLabel("Venus"));
    h.put (new Integer (3), new JLabel("Earth"));
    h.put (new Integer (4), new JLabel("Mars"));
    h.put (new Integer (5), new JLabel("Jupiter"));
    h.put (new Integer (6), new JLabel("Saturn"));
    h.put (new Integer (7), new JLabel("Uranus"));
    h.put (new Integer (8), new JLabel("Neptune"));
    h.put (new Integer (9), new JLabel("Pluto"));
    right.setLabelTable (h);
    right.setPaintLabels (true);
    right.setInverted (true);
    bottom = new JSlider(JSlider.HORIZONTAL, 0, 100, 25);
    bottom.setMajorTickSpacing (10);
    bottom.setPaintLabels (true);
    add(right, BorderLayout.EAST);
    add(bottom, BorderLayout.SOUTH);
  }
  public static void main (String args[]) {
    JFrame f = new JFrame ("JSlider Label Example");
    JPanel j = new SliderPanel2 ();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (300, 200);
    f.show();
  }
}

