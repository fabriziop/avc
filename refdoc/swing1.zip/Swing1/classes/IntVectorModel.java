import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

public class IntVectorModel {
  protected Vector data = new Vector();
  protected EventListenerList changeListeners =
    new EventListenerList();

  public IntVectorModel() {
  }

  public void addElement(int i) {
    data.addElement(new Integer(i));
    fireChange();
  }

  public Vector getData() {
    return data;
  }

  // Listener notification support
  public void addChangeListener(ChangeListener x) {
    changeListeners.add (ChangeListener.class, x);

    // bring it up to date with current state
    x.stateChanged(new ChangeEvent(this));
  }

  public void removeChangeListener(ChangeListener x) {
    changeListeners.remove (ChangeListener.class, x);
  }

  protected void fireChange() {
    // Create the event:
    ChangeEvent c = new ChangeEvent(this);
    // Get the listener list
    Object[] listeners = 
      changeListeners.getListenerList();
    // Process the listeners last to first
    // List is in pairs, Class and instance
    for (int i = listeners.length-2; i >= 0; i -= 2) {
      if (listeners[i] == ChangeListener.class) {
        ChangeListener cl = 
          (ChangeListener)listeners[i+1];
        cl.stateChanged(c);
      }
    }
  }
}
