/* This is a basic application that demonstrates a
 * simple way to establish interaction among widgets
 * in a GUI. Its event framework is fine for simple
 * applications. Some shortcomings will be outlined
 * below. It places a JTextField and a JTextArea on
 * the screen. An ActionListener is added to the
 * JTextField, so that, upon entering text into the
 * JTextField, a line with the same text is appended
 * to the JTextArea.
 */

// First, import the swing and awt symbols
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/* The class is going to extend JFrame
* Most of the work of setting up the GUI
* will be done in the constructor for the frame
* Additionally, add a main method so you can
* run it as an application
*/ 
public class SimpleEvents extends JFrame {

  // Constants to specify width and height of frame
  // Used below in the main method
  static final int WIDTH=350;
  static final int HEIGHT=180;

  // Declare a JTextField for getting user input
  JTextField textField;

  // Declare a JTextArea for receiving lines of
  // text from textField
  JTextArea textList;

  // Declare a JScrollPane to hold the JTextArea
  JScrollPane pane;

  // Constructor for the frame class
  public SimpleEvents(String lab) {
    // Call JFrame's constructor
    // This will set the label of the JFrame
    super(lab);
  
/********** Create a container for the textField *****/

    // Instantiate a JPanel
    JPanel textPanel = new JPanel();

    // Give it a border so it stands out
    // By default, panels have no border
    textPanel.setBorder (
      BorderFactory.createEtchedBorder());
  
    // Set the layout of the textPanel to a BorderLayout
    textPanel.setLayout(new BorderLayout());

    // Create a label and add it to the panel
    JLabel textTitle = 
      new JLabel("Type and hit <ENTER>");
    textPanel.add(textTitle, BorderLayout.NORTH);

    // Instantiate JTextField and add it to the textPanel
    textField = new JTextField();
    textPanel.add(textField, BorderLayout.SOUTH);

/******** Create a container for the textArea ********/

    // Instantiate a JPanel
    JPanel listPanel = new JPanel();

    // Give it a border so it stands out
    listPanel.setBorder (
      BorderFactory.createEtchedBorder());

    // Set the layout of the textPanel to a BoxLayout
    // BoxLayouts are discussed below (ignore for now)
    listPanel.setLayout(
      new BoxLayout(listPanel,BoxLayout.Y_AXIS));

    // Create a label and add it to the panel
    JLabel title = new JLabel("Text List");
    listPanel.add(title);

    // Add a strut to the BoxLayout
    listPanel.add(Box.createVerticalStrut(10));

    // Instantiate the JTextArea with no initial text,
    // 6 rows, 10 columns, and vertical scrollbars
    textList=new JTextArea("", 6, 10);

    // Make it read-only
    textList.setEditable(false);

    // Add the the textList to the listPanel
    pane = new JScrollPane (textList);
    listPanel.add(pane);

    // Add a strut to the listPanel as a bottom margin
    listPanel.add(Box.createVerticalStrut(6));

/***** Add a listener to the textField ***************/

    /* The listener will respond to user input by 
     * copying the textField's text to the textList.
     * The ENTER key causes an ActionEvent to be
     * generated. Notice how the two widgets are
     * becoming intertwined. 
     * Changes to one will likely affect the other
     */
    textField.addActionListener(new ActionListener() {           
      public void actionPerformed(ActionEvent e) {
        // Append the textField's text to textList
        textList.append(textField.getText());
        textList.append("\n");
        // Reset the textField
        textField.setText("");
      }
    });

    // Add two panels to frame, separated by a strut
    Container c = getContentPane();
    c.setLayout (new FlowLayout());
    c.add(textPanel);
    c.add(Box.createHorizontalStrut(30));
    c.add(listPanel);
 }  

/* Create a main method for invoking as application **/
  public static void main(String args[]) {
    // Instantiate instance of the SimpleEvents class
    // This is where constructor is executed, and the
    // GUI built - JFrame title is passed as parameter
    SimpleEvents frame = 
      new SimpleEvents("Simple Events Example");

    // This is a standard adapter that should be 
    // in most applications. It closes the window
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });

    // Set the size of the JFrame and show it
    frame.setSize(WIDTH, HEIGHT);
    frame.setVisible(true);
 }
}
