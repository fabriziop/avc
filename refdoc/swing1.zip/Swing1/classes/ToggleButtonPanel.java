import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ToggleButtonPanel extends JPanel {

  public ToggleButtonPanel() {
    // Set the layout to a GridLayout
    setLayout(new GridLayout(4,1, 10, 10));

    add (new JToggleButton ("Fe"));
    add (new JToggleButton ("Fi"));
    add (new JToggleButton ("Fo"));
    add (new JToggleButton ("Fum"));

  }

  public static void main (String args[]) {
    JFrame f = new JFrame ("ToggleButton Example");
    f.setBackground (Color.lightGray);
    JPanel j = new ToggleButtonPanel();
    f.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    f.getContentPane().add (j, BorderLayout.CENTER);
    f.setSize (200, 200);
    f.show();
  }
}
